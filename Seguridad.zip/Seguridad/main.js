﻿
function cadastrar() {
    alert('eeebaaa');
}